import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-hotel-edit',
  templateUrl: './hotel-edit.component.html',
  styleUrls: ['./hotel-edit.component.css']
})
export class HotelEditComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
