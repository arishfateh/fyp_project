import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-itinerary-edit',
  templateUrl: './itinerary-edit.component.html',
  styleUrls: ['./itinerary-edit.component.css']
})
export class ItineraryEditComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
