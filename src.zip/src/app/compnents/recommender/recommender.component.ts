import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-recommender',
  templateUrl: './recommender.component.html',
  styleUrls: ['./recommender.component.css']
})
export class RecommenderComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
