import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-stay-edit',
  templateUrl: './stay-edit.component.html',
  styleUrls: ['./stay-edit.component.css']
})
export class StayEditComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
