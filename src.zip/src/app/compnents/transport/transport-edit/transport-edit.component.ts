import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-transport-edit',
  templateUrl: './transport-edit.component.html',
  styleUrls: ['./transport-edit.component.css']
})
export class TransportEditComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
