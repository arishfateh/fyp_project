import { AttractionPoint } from './attraction-point.model';

describe('AttractionPoint', () => {
  it('should create an instance', () => {
    expect(new AttractionPoint()).toBeTruthy();
  });
});
