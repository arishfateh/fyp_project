export class AttractionPoint {
    ID: string;
    AttractionName: string;
    City: string;
    Type: string;
    Price: number;
    Priority: number;
    Time: number;
    travelDistance: number;
    travelTime: number;
    Description: string;
    timeSlots: number;

}

