import { Breakpoints } from './breakpoints.model';

describe('Breakpoints', () => {
  it('should create an instance', () => {
    expect(new Breakpoints()).toBeTruthy();
  });
});
