export class Breakpoints {
    ID: string;
    StartPoint: string;
    EndPoint: string;
    StopType: string;
    Priority: number;
    Time: number;
}
