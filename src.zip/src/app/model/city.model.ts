export class City {
    ID: string;
    CityName: string;
    StayPriority: number;
    Latitude: String;
    Longitude: String;
    MaximumStop: number;

}
