import { Days } from './days';

describe('Days', () => {
  it('should create an instance', () => {
    expect(new Days()).toBeTruthy();
  });
});
