import { FixedTransport } from './fixed-transport.model';

describe('FixedTransport', () => {
  it('should create an instance', () => {
    expect(new FixedTransport()).toBeTruthy();
  });
});
