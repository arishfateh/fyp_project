export class FixedTransport {
    ID: string;
    City: string;
    NoOfVehicles: number;
    VendorName: string;
    VendorPhoneNo: string;
    StartPoint: string;
    EndPoint: string;
    Price: number;
}
