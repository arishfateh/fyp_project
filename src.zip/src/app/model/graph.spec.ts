import { Graph } from './graph';

describe('Graph', () => {
  it('should create an instance', () => {
    expect(new Graph()).toBeTruthy();
  });
});
