import { ItineraryDays } from './itinerary-days.model';

describe('ItineraryDays', () => {
  it('should create an instance', () => {
    expect(new ItineraryDays()).toBeTruthy();
  });
});
