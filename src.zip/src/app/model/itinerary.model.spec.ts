import { Itinerary } from './itinerary.model';

describe('Itinerary', () => {
  it('should create an instance', () => {
    expect(new Itinerary()).toBeTruthy();
  });
});
