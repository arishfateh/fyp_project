import { Jeep } from './jeep.model';

describe('Jeep', () => {
  it('should create an instance', () => {
    expect(new Jeep()).toBeTruthy();
  });
});
