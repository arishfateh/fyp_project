import { RoomType } from './room-type.model';

describe('RoomType', () => {
  it('should create an instance', () => {
    expect(new RoomType()).toBeTruthy();
  });
});
