export class RoomType {
    roomType: string;
    NoOfRooms: number;
    Price: number;
    Occupancy: number;
    RoomServices: Array<string> = [];
}
