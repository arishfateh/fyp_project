import { Rooms } from './rooms.model';

describe('Rooms', () => {
  it('should create an instance', () => {
    expect(new Rooms()).toBeTruthy();
  });
});
