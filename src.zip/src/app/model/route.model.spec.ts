import { Route } from './route.model';

describe('Route', () => {
  it('should create an instance', () => {
    expect(new Route()).toBeTruthy();
  });
});
