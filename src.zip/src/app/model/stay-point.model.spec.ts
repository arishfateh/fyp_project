import { StayPoint } from './stay-point.model';

describe('StayPoint', () => {
  it('should create an instance', () => {
    expect(new StayPoint()).toBeTruthy();
  });
});
