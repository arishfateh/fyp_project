export class StayPoint {
    ID: string;
    DepartureCity: string;
    DestinationCity: string;
    StopOverCity: string;
    Priority: number;
}

