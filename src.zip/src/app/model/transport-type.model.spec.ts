import { TransportType } from './transport-type.model';

describe('TransportType', () => {
  it('should create an instance', () => {
    expect(new TransportType()).toBeTruthy();
  });
});
