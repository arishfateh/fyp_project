export class TransportType {
    TransportName: string;
    Capacity: number;
    Price: number;
}
