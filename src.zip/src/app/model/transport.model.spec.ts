import { Transport } from './transport.model';

describe('Transport', () => {
  it('should create an instance', () => {
    expect(new Transport()).toBeTruthy();
  });
});
