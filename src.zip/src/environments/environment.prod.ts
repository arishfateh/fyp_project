export const environment = {
  production: true,
  firebaseConfig: {
    apiKey: "AIzaSyDyqgaBIUVvpa9LwE7PHifsY58SVQ3Nbmo",
    authDomain: "fypproject-38b48.firebaseapp.com",
    databaseURL: "https://fypproject-38b48.firebaseio.com",
    projectId: "fypproject-38b48",
    storageBucket: "",
    messagingSenderId: "405660426197",
    appId: "1:405660426197:web:f404a478aba3efc8"
  }
};
